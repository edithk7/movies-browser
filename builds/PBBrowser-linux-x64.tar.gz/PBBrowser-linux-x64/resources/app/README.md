# movies-browser
Electron movies browser.

Main screen (shows info, download and delete buttons on hover)
![alt tag](http://i.imgur.com/grbo6VE.png "Main Screen")

Reviews screen (shows imdb reviews on click)
![alt tag](http://i.imgur.com/Tq7njZb.png "Reviews Screen")